// components/Divider.jsx
export default function Divider() {
  return <div className="my-8 h-px w-full bg-white/10" />;
}
